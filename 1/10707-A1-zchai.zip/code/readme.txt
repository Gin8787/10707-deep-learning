Please excute the neural_network2.m in the command line of matlab with the command
including the paramters like this:
neural_network2(datapath, datapath_validate, datapath_test, hidden_layers_size, minibatch_size, minibatch_times, epochs, learning_rate, regularization_param, momentum)


***********************************Explaintion of parameters*************************************

datapath: the path of the training data, like 'traindata.txt'

datapath_validate: the path of the validation data, like 'validatedata.txt'

hdden_layer_size: a vector that contains the number of neurons for each hidden layer, like [100, 200], which means there are 2 hidden layers, one has 100 neurons, and another has 200 neurons

minibatch_size: the size of minibath, like 256

minibatch_times: in each epoch, how many time you want to pick the minibatch, like '10', which means in each epoch, the program will pick 10 times the minibatch, and do the backpropagate 10 times.

epochs: number of epochs, like 200

learning_rate: learning rate, like 0.01

regularization_param: the number used to do the L2 regulirazation, use the formula: regularizetion_coef = 1 - learning_rate * regularization_param / 3000, where 3000 is the size of training data.
                      So the regularization_param usually will be bigger than 500, or the formula will get a 0 after the calculation.

momentum: momentum parameters, like 0.1




***************************A tipical commond will be like this************************************

neural_network2('digitstrain.txt', 'digitsvalidate.txt', 'digitstest.txt' , 100, 256, 10, 200, 0.01, 3000, 0.1)
