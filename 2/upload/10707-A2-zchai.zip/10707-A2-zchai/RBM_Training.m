function [] = RBM_Training(datapath, datapath_validate, hidden_num, minibatch_size, epochs, learning_rate, K)
[data1] = textread('digitstrain.txt','','delimiter',',');
[data2] = textread('digitsvalid.txt','','delimiter',',');

data = vec2mat(data1, 785);

data_validate = vec2mat(data2, 785);


data_dim = 784;
data_num = 3000;
data_num_validate = 1000;

%process validation data
[x_validate, labels] = process_data(data_validate);


%initialize parameters
[weights, hid_bias, vis_bias] = param_init(data_dim, hidden_num);
%hidden probability of positive phase
pos_hid_probs = zeros(minibatch_size, hidden_num);
%hidden probability of negtive phase
neg_hid_probs = zeros(minibatch_size, hidden_num);
%positve term = h(x_t)x_t, dimension is the same as weights
pos_prods = zeros(data_dim, hidden_num);
%negtive term = h(x_k)x_k, dimension is the same as weights
neg_prods = zeros(data_dim, hidden_num);
%weights delta
weights_delta = zeros(data_dim, hidden_num);
%hid_bias delta
hid_bias_delta = zeros(1, hidden_num);
%vis_bias delta
vis_bias_delat = zeros(1, data_dim);

%In each epoch, number of batches we need
batch_num = floor(3000 / minibatch_size);

%Loss array for train and validation
loss_train = zeros(1, epochs);
loss_validate = zeros(1, epochs);

%stochastic reconstruction for debug
average_train = zeros(1, epochs);
average_validate = zeros(1, epochs);

for epoch = 1 : 1 : epochs
    [x, labels] = process_data(data);
    for batch = 1 : 1 : batch_num
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%Gibbs Sampling%%%%%%%%%%%%%%%%%%%%%%%%%
        %x_0 = data, h(x_0) = p(h|x_0), pos_prods = x_0 * h(x_0)
        %initial x_K with the training data examples
        x_0 = x(((batch-1)*minibatch_size + 1) : batch*minibatch_size, :);
        % Get hidden variables' probability by the formula p(h|x)
        pos_hid_probs = 1./(1 + exp(-x_0 * weights - repmat(hid_bias, minibatch_size, 1)));
        % positvie term for weight_delta: h(x_0) * x_0, this value will be
        % used to calculate delta
        pos_prods = x_0' * pos_hid_probs;
        %this value will be used to do the iteration
        pos_hid_probs_itr = pos_hid_probs;
        for k = 1 : 1 : K
            %%%%%%%%%%%%%start of positive phase%%%%%%%%%%
            if k ~= 1
                % x_k is the negtive data from the last iteration
                pos_hid_probs_itr = 1 ./ (1 + exp(-x_k*weights - repmat(hid_bias, minibatch_size, 1)));
            end
            %%%%%%%%%%%%%end of positive phase%%%%%%%%%%%%
            
            % sample hidden variables according to the probability
            % p(h|x)=pos_hid_probs_itr
            pos_hid_variables = pos_hid_probs_itr > rand(minibatch_size, hidden_num);
            
            %%%%%%%%%%%%%%%start of negtive phase%%%%%%%%%%%%%%
            % reconstruct the data x_k from the positive hidden variables
            % by using the formula p(x|h)
            x_k = 1 ./ (1 + exp(-pos_hid_variables*weights' - repmat(vis_bias, minibatch_size, 1)));
            %%%%%%%%%%%%%%%end of negtive phase%%%%%%%%%%%%%%%%
        end
        % use negative data to inference negative hidden probability by
        % using p(h|x)
        neg_hid_probs = 1 ./ (1 + exp(-x_k * weights - repmat(hid_bias, minibatch_size, 1)));
        % negtive term for weight_delta: h(x_k) * x_k, this value will be
        % used to calculate delta
        neg_prods = x_k' * neg_hid_probs;
        %size(neg_prods)
        %%%%%%%%%%%%%%%%%%%%%%end of Gibbs Sampling%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        %%%%%%%%%%%%%%%%%%%%%%Update Parameters%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        weights_delta = learning_rate .* (pos_prods - neg_prods) ./ minibatch_size;
        hid_bias_delta = learning_rate .* (sum(pos_hid_probs) - sum(neg_hid_probs)) ./ minibatch_size; 
        vis_bias_delta = learning_rate .* (sum(x_0) - sum(x_k)) ./ minibatch_size;
        weights = weights + weights_delta;
        hid_bias = hid_bias + hid_bias_delta;
        vis_bias = vis_bias + vis_bias_delta;
        %%%%%%%%%%%%%%%%%%%%%%End of Update Parameters%%%%%%%%%%%%%%%%%%%%%
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%Calculate Loss%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    epoch
    
    %%%%%%%%%%%%%%%%Training Data%%%%%%%%%%%%%%
    hid_prob_loss_train = 1 ./ (1 + exp(-x * weights - repmat(hid_bias, data_num, 1)));
    hid_varible_loss_train = hid_prob_loss_train > rand(data_num, hidden_num);
    data_reconstruct_train = 1 ./ (1 + exp(-hid_varible_loss_train*weights' - repmat(vis_bias, data_num, 1)));
    cross_entropy_train = -sum(x .* log(data_reconstruct_train)) ./ data_num;
    loss_train(1, epoch) = sum(cross_entropy_train);
    %data_reconstruct_train(1, :)
    %debug
    x_difference_train = x - data_reconstruct_train;
    x_square_train = x_difference_train .^ 2;
    average_x_train = sum(x_square_train(:)) ;
    average_train(1, epoch) = average_x_train;
    %%%%%%%%%%%End of Training Data%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%Validation data%%%%%%%%%%%%%%
    hid_prob_loss_validate = 1 ./ (1 + exp(-x_validate * weights - repmat(hid_bias, data_num_validate, 1)));
    hid_variable_loss_validate = hid_prob_loss_validate > rand(data_num_validate, hidden_num);
    data_reconstruct_validate = 1 ./ (1 + exp(-hid_variable_loss_validate*weights' - repmat(vis_bias, data_num_validate, 1)));
    cross_entropy_validate = -sum(x_validate .* log(data_reconstruct_validate)) ./ data_num_validate;
    loss_validate(1, epoch) = sum(cross_entropy_validate);
    %data_reconstruct_validate(1, :)
    %debug
    x_difference_validate = x_validate - data_reconstruct_validate;
    x_square_validate = x_difference_validate .^ 2;
    average_x_validate = sum(x_square_validate(:)) ;
    average_validate(1, epoch) = average_x_validate;
    %%%%%%%%%%%End of Validation Data%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%End of Calculating Loss%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%Shuffle data%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    data = data(randperm(size(data,1)), :);
    %%%%%%%%%%%%%%%%%%%%%%%%%end of Shuffle data%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end

%%%%%%%%Plot cross-entropy loss%%%%%%%%
figure(1)
plot(loss_train)
hold on;
plot(loss_validate, 'red');
xlabel('epochs');
ylabel('cross entropy loss');
hold off;

%%%%%%%%End of plotting cross-entropy loss%%%%%

%%%%%%%visualize weights%%%%%%%%%
visualize_weights(weights)
%%%%End of visualize weights%%%%%

write_parameters(weights, "rbm_weight.txt");
write_parameters(hid_bias, "rbm_hid_bias.txt");
write_parameters(vis_bias, "rbm_vis_bias.txt");

end

function [x, label] = process_data(data)
x = data(:, 1 : 784);
label = data(:, 785);
end

function [weights, hid_bias, vis_bias] = param_init(data_dim, hidden_num)
% use Guassian distribution with miu = 0, and sigma = 0.1
weights = normrnd(0, 0.1, [data_dim, hidden_num]);
hid_bias = zeros(1, hidden_num);
vis_bias = zeros(1, data_dim);
end

function visualize_weights(weights)
[row, col] = size(weights);
figure(2)
set(gca, 'Units', 'normalized', 'Position', [0 0 0 0]);
for i = 1 : 1 : col
    matrix_temp = weights(:, i);
    weight = reshape(matrix_temp, 28, 28);
    subplot(col / 10, 10, i)
    imshow(weight)
end
end

function write_parameters(paramters, path)
fid = fopen(path, 'w');
[row, col] = size(paramters);
for i = 1 : 1 : row
    for j = 1 : 1 : col - 1
        fprintf(fid, '%f,', paramters(i, j));
    end
    fprintf(fid, '%f\n', paramters(i, j));
end
fclose(fid);
end
