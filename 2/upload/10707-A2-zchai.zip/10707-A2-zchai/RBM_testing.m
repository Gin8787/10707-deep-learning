function [] = RBM_Testing(K)
    weights = textread('rbm_weights.txt', '', 'delimiter',',');
    hid_bias = textread('rbm_hid_bias.txt', '', 'delimiter', ',');
    vis_bias = textread('rbm_vis_bias.txt', '', 'delimiter', ',');
    [data] = textread('digitstest.txt', '', 'delimiter', ',');
    data = data(randperm(size(data,1)), :);
    [x, labels] = process_data(data);
    x_0 = x(301:400, :);
    x_0 = rand(100, 784)
    pos_hid_probs = 1./(1 + exp(-x_0 * weights - repmat(hid_bias, 100, 1)));
    %this value will be used to do the iteration
    pos_hid_probs_itr = pos_hid_probs;
    for k = 1 : 1 : K
        k
        %%%%%%%%%%%%%start of positive phase%%%%%%%%%%
        if k ~= 1
            % x_k is the negtive data from the last iteration
            pos_hid_probs_itr = 1 ./ (1 + exp(-x_k*weights - repmat(hid_bias, 100, 1)));
         end
         %%%%%%%%%%%%%end of positive phase%%%%%%%%%%%%
            
         % sample hidden variables according to the probability
         % p(h|x)=pos_hid_probs_itr
         pos_hid_variables = pos_hid_probs_itr > rand(100, 100);
            
         %%%%%%%%%%%%%%%start of negtive phase%%%%%%%%%%%%%%
         % reconstruct the data x_k from the positive hidden variables
         % by using the formula p(x|h)
         x_k = 1 ./ (1 + exp(-pos_hid_variables*weights' - repmat(vis_bias, 100, 1)));
         x_k = x_k > rand(100, 784);
         %%%%%%%%%%%%%%%end of negtive phase%%%%%%%%%%%%%%%%
    end
    
    visualize_reconstruction(x_k);
end

function visualize_reconstruction(x_k)
size(x_k)
[row, col] = size(x_k);
figure(2)
set(gca, 'Units', 'normalized', 'Position', [0 0 0 0]);
for i = 1 : 1 : row
    matrix_temp = x_k(i, :);
    weight = reshape(matrix_temp, 28, 28);
    subplot(row / 10, 10, i)
    imshow(weight')
end
end

function [x, label] = process_data(data)
x = data(:, 1 : 784);
label = data(:, 785);
end