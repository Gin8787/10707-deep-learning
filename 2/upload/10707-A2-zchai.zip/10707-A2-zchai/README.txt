There are 4 .m files, and 3 data files in the /code folder:
RBM_Training.m, RBM_Testing.m, auto_encoder.m, neural_network2.m
digitstrain.txt, digitsvalid.txt, digitstest.txt

*********************************************************************************

Use four matlab command to run the four .m files:
RBM_Training.m
RBM_Training(datapath, datapath_validate, hidden_num, minibatch_size, epochs, learning_rate, K);
-datapath: training datapath
-datapath_validate: validate datapath
-hidden_num: number of hidden units
-minibatch_size: the size of minibatch
-epochs: epochs
-learning_rate: learning rate
-K: steps of Gibbs sampling

-----------------------------------------------------------------------------------

RBM_Testing.m
RBM_Testing(K)
-K: steps of Gibbs sampling

-----------------------------------------------------------------------------------

auto_encoder.m
auto_encoder(hidden_num, minibatch_size, epochs, learning_rate, denoising);
-hidden_num: number of hidden units
-epochs: number of epochs
-learning_rate; learning rate
-denoising: dropout percentate(use 0.1 to dropout 10% input)

-----------------------------------------------------------------------------------

neural_network2.m
neural_network2(datapath, datapath_validate, datapath_test, hidden_layers_size, minibatch_size, minibatch_times, epochs, learning_rate, regularization_param, momentum, rbm_auto);
-datapath: training datapath
-datapath_validate: validate datapath
-datapath_test: testing datapath
-hidden_layers_size: number of hidden layers
-minibatch_size: size of minibatch
-minibatch_times: number of updating parameters in one epoch
-epochs: number of epochs:
-learning_rate: learning rate
-reularization_param: regularization parameters(greater than 500)
-momentum: momentum parameters(0-1)
-rbm_auto: to use weights pretrained by rbm, this parameter should be 1, to use weights pretrained by autoencoder, this parameters should be 2. 

*********************************************************************************

5-a) RBM_Training("digitstrain.txt", "digitsvalid.txt", 100, 200, 400, 0.1, 1)
5-b) a. RBM_Training("digitstrain.txt", "digitsvalid.txt", 100, 200, 100, 0.1, 5)
		RBM_Training("digitstrain.txt", "digitsvalid.txt", 100, 200, 100, 0.1, 10)
		RBM_Training("digitstrain.txt", "digitsvalid.txt", 100, 200, 100, 0.1, 20)
5-c) a. RBM_Training("digitstrain.txt", "digitsvalid.txt", 100, 200, 100, 0.1, 1)
	 b. RBM_testing(5000)
5-d) a. RBM_Training("digitstrain.txt", "digitsvalid.txt", 100, 200, 500, 0.1, 1)
     b. neural_network2("digitstrain.txt", "digitsvalid.txt", "digitstest.txt", 100, 200, 15, 100, 0.01, 1000, 0, 1)
5-e) a. auto_encoder(100, 32, 500, 0.1, 0)
     b. neural_network2("digitstrain.txt", "digitsvalid.txt", "digitstest.txt", 100, 200, 15, 100, 0.01, 1000, 0, 2)
5-f) a. auto_encoder(100, 32, 250, 0.1, 0.1)
     b. neural_network2("digitstrain.txt", "digitsvalid.txt", "digitstest.txt", 100, 200, 15, 100, 0.01, 1000, 0, 2) 
5-g) a. BM_Training("digitstrain.txt", "digitsvalid.txt", 50, 200, 100, 0.1, 1)
	    BM_Training("digitstrain.txt", "digitsvalid.txt", 100, 200, 100, 0.1, 1)
	    BM_Training("digitstrain.txt", "digitsvalid.txt", 200, 200, 100, 0.1, 1)
	    BM_Training("digitstrain.txt", "digitsvalid.txt", 100, 500, 100, 0.1, 1)
	 b. auto_encoder(50, 32, 250, 0.1, 0)
	 	auto_encoder(100, 32, 250, 0.1, 0)
	 	auto_encoder(200, 32, 250, 0.1, 0)
	 	auto_encoder(500, 32, 250, 0.1, 0)
	 c. auto_encoder(50, 32, 250, 0.1, 0.1)
	 	auto_encoder(100, 32, 250, 0.1, 0.1)
	 	auto_encoder(200, 32, 250, 0.1, 0.1)
	 	auto_encoder(500, 32, 250, 0.1, 0.1)
