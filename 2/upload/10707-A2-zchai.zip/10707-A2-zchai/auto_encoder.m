function [] = auto_encoder(hidden_num, minibatch_size, epochs, learning_rate, denoising)
[data1] = textread('digitstrain.txt','','delimiter',',');
[data2] = textread('digitsvalid.txt','','delimiter',',');

data = vec2mat(data1, 785);

data_validate = vec2mat(data2, 785);


data_dim = 784;
data_num = 3000;
data_num_validate = 1000;

%process validation data
[x_validate, labels] = process_data(data_validate);

%Loss array for train and validation
loss_train = zeros(1, epochs);
loss_validate = zeros(1, epochs);

%In each epoch, number of batches we need
batch_num = floor(3000 / minibatch_size);

weights = normrnd(0, 0.1, [data_dim, hidden_num]);
en_bias = zeros(1, hidden_num);
de_bias = zeros(1, data_dim);
h_x = zeros(1, hidden_num);

if denoising == 0
    denoising_mat = ones(minibatch_size, data_dim);
else
    denoising_mat = rand(minibatch_size, data_dim) > denoising;
    denoising_mat
end

for epoch = 1 : 1 : epochs
    [x, labels] = process_data(data);
    
    for batch = 1 : 1 : batch_num
        x_0 = x(((batch-1)*minibatch_size + 1) : batch*minibatch_size, :);
        x_0 = x_0 .* denoising_mat;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%Encoding%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        h_x = 1 ./ (1 + exp(-x_0 * weights - repmat(en_bias, minibatch_size, 1)));
        %%%%%%%%%%%%%%%%%%%%%%%%%%End of Encoding%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%Decoding%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        x_head = 1 ./ (1 + exp(-h_x * weights' - repmat(de_bias, minibatch_size, 1)));
        %%%%%%%%%%%%%%%%%%%%%%%%%%End of Decoding%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%Backpropagation%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%Delta of Decoder%%%%%%%
        delta_decoder = (x_head - x_0);
        weights_delta_decode = h_x' * delta_decoder;
        %%%End of Delta of Decoder%%%%%%%
        
        %%%Delta of Encoder%%%%%%%
        delta_sum = delta_decoder * weights;
        delta_encoder = delta_sum .* (h_x .* (1 - h_x));
        weights_delta_encode = x_0' * delta_encoder;
        %%%End of Delta of Encoder%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%End of Backprogation%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%Update Weights%%%%%%%%%%%%%%%%%%%%%%%%%%%
        weights_delta_decode = weights_delta_decode ./ minibatch_size;
        weights_delta_encode = weights_delta_encode ./ minibatch_size;
        en_bias_delta = sum(delta_encoder) ./ minibatch_size;
        de_bias_delta = sum(delta_decoder) ./ minibatch_size;
        
        weights = weights - learning_rate .* ( weights_delta_decode' + weights_delta_encode);
        en_bias = en_bias - learning_rate .* en_bias_delta;
        de_bias = de_bias - learning_rate .* de_bias_delta;
        %%%%%%%%%%%%%%%%%%%%%%%End of Update Weights%%%%%%%%%%%%%%%%%%%%%%%
        
        
    end
    
    epoch
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%Calculate Loss%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%Training Data%%%%%%%%%%%%%%
    hidden_train = 1 ./ (1 + exp(-x * weights - repmat(en_bias, data_num, 1)));
    x_head_train = 1 ./ (1 + exp(-hidden_train * weights' - repmat(de_bias, data_num, 1)));
    cross_entropy_train = (-sum(x .* log(x_head_train))) ./ data_num;
    loss_train(1, epoch) = sum(cross_entropy_train);
    %%%%%%%%%%%End of Training Data%%%%%%%%%%%%

    %%%%%%%%%%%%%%%Validation data%%%%%%%%%%%%%%
    hidden_validate = 1 ./ (1 + exp(-x_validate * weights - repmat(en_bias, data_num_validate, 1)));
    x_head_validate = 1 ./ (1 + exp(-hidden_validate * weights' - repmat(de_bias, data_num_validate, 1)));
    cross_entropy_validate = (-sum(x_validate .* log(x_head_validate))) ./ data_num_validate;
    loss_validate(1, epoch) = sum(cross_entropy_validate);
    %%%%%%%%%%%End of Validation Data%%%%%%%%%%%
    
    
    %%%%%%%%%%%%%%%%%%%%%%End of Calculating Loss%%%%%%%%%%%%%%%%%%%%%%%%%%


    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%Shuffle data%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    data = data(randperm(size(data,1)), :);
    %%%%%%%%%%%%%%%%%%%%%%%%%end of Shuffle data%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end

figure(1)
plot(loss_train)
hold on;
plot(loss_validate, 'red');
xlabel('epochs');
ylabel('cross entropy loss');
hold off;

%%%%%%%visualize weights%%%%%%%%%
visualize_weights(weights)
%%%%End of visualize weights%%%%%

write_parameters(weights, "auto_weight.txt");
write_parameters(en_bias, "atuo_en_bias.txt");
write_parameters(de_bias, "atuo_de_bias.txt");

end

function [x, label] = process_data(data)
x = data(:, 1 : 784);
label = data(:, 785);
end

function visualize_weights(weights)
[row, col] = size(weights);
figure(2)
set(gca, 'Units', 'normalized', 'Position', [0 0 0 0]);
for i = 1 : 1 : col
    matrix_temp = weights(:, i);
    weight = reshape(matrix_temp, 28, 28);
    subplot(col / 10, 10, i)
    imshow(weight)
end
end

function write_parameters(paramters, path)
fid = fopen(path, 'w');
[row, col] = size(paramters);
for i = 1 : 1 : row
    for j = 1 : 1 : col - 1
        fprintf(fid, '%f,', paramters(i, j));
    end
    fprintf(fid, '%f\n', paramters(i, j));
end
fclose(fid);
end
