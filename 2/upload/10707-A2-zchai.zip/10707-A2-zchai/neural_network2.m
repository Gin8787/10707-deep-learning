function [] = neural_network2(datapath, datapath_validate, datapath_test, hidden_layers_size, minibatch_size, minibatch_times, epochs, learning_rate, regularization_param, momentum, rbm_auto)
data = textread('digitstrain.txt','','delimiter',',');

data_validate = textread('digitsvalid.txt','','delimiter',',');
data_test = textread('digitstest.txt', '', 'delimiter', ',');
% process the validation data
[x_validate, labels_validate] = process_data(data_validate);

[x_test, labels_test] = process_data(data_test);

layers_num = length(hidden_layers_size) + 1;

[weights_cell, biases_cell, activations_cell, weights_del_cell, biases_del_cell, weigths_del_prev_cell] = para_initial(hidden_layers_size, minibatch_size);

loss_change = zeros(1, epochs);
loss_change_validate = zeros(1, epochs);
failure_num_plot = zeros(1, epochs);
failure_num_validate_plot = zeros(1,epochs);

if rbm_auto == 1
    weights_layer1 = textread('rbm_weights.txt', '', 'delimiter',',');
    weights_cell{1, 1} = weights_layer1';
    %size(weights_layer1)
elseif rbm_auto == 2
    weights_layer1 = textread('auto_weight.txt', '', 'delimiter',',');
    weights_cell{1, 1} = weights_layer1';
    %size(weights_layer1)
end


for epoch = 1 : 1 : epochs
    loss = zeros(minibatch_size, 1);
    success_num = 0;
    for minibatch_time = 1 : 1 : minibatch_times
        [x, lables] = process_data(data);
        
        % layey_input is initialized with one piece of the training data
         layer_input = x(1 : minibatch_size, :);
        %layer_input = x(1 + minibatch_time * minibatch_size:(minibatch_time+1)* minibatch_size, :);
        
        % target is the correct classification of the training data
        target = zeros(minibatch_size, 10);
        
        % set the target value to be one at the right position
        lable = lables(1 : minibatch_size, 1);
        %lable = lables(1 + minibatch_time * minibatch_size:(minibatch_time+1)* minibatch_size, :);
        target = initial_target(target, lable, minibatch_size);
        
        [weights_cell, biases_cell, activations_cell] = feedforward(weights_cell, biases_cell, activations_cell, layer_input, layers_num);
        [weights_del_cell, biases_del_cell] = propagation(activations_cell, weights_del_cell, biases_del_cell, weights_cell, x(1 : minibatch_size, :), layers_num, target);
        
        network_output = activations_cell{1, layers_num};
        loss =  loss + cross_entropy(network_output, target);
        success = classification_success(network_output, target);
        success_num = success_num + success;
        
        regularizetion_coef = 1 - learning_rate * regularization_param / 3000;
        
        for i = 1 : 1 : layers_num
            weights_delta = weights_del_cell{1, i};
            weights_delta = weights_delta ./ minibatch_size + momentum .* weigths_del_prev_cell{1, i};
            biases_delta = biases_del_cell{1, i} ./ minibatch_size;
            weights_new = regularizetion_coef .* weights_cell{1 , i} - learning_rate .* weights_delta;
            
            biases_new = biases_cell{1, i} - learning_rate .* biases_delta;
            
            weights_cell{1, i} = weights_new;
            biases_cell{1, i} = biases_new;
            % plot the weights image
            %             if (i == 1) && (epoch == epochs)
            %                 image_mat = construct_image_matrix(weights_new, 100);
            %                 figure(2)
            %                 imshow(image_mat);
            %             end
            weigths_del_prev_cell{1, i} = weights_delta;
        end
        % shuffle the whole data set to do minibatch B = A(randperm(size(A,1)),:)
        %weights_cell = constrcut_weights_cell(hidden_layers_size);
        %biases_cell = construct_biases_cell(hidden_layers_size);
        data = data(randperm(size(data,1)), :);
    end
    loss_for_epoch = sum(loss) / (minibatch_times * minibatch_size);
    loss_change(1, epoch) = loss_for_epoch;
    accuracy = success_num / (minibatch_times * minibatch_size);
    failure_num_plot(1, epoch) = 1 - accuracy;
    
    data = data(randperm(size(data,1)), :);
    
    [loss_validate, success_num_validate] = validate_network(weights_cell, biases_cell, layers_num ,x_validate, labels_validate);
    accuracy_validate = success_num_validate / 1000;
    failure_num_validate_plot(1, epoch) = 1 - accuracy_validate;
    loss_change_validate(1, epoch) = sum(loss_validate) / 1000;

    % consol print
    epoch
    loss_for_epoch
    accuracy
end

[loss_testing, success_num_testing] = test_network(weights_cell, biases_cell, layers_num, x_test, labels_test);
accuracy_testing = success_num_testing / 3000;
loss_testing = sum(loss_testing) / 3000;
loss_testing
accuracy_testing

figure(3)


plot(loss_change);
hold on;
plot(loss_change_validate, 'red');
xlabel('epochs')
ylabel('cross entropy loss')
hold off;

figure(4)

plot(failure_num_plot);
hold on;
plot(failure_num_validate_plot, 'red');
xlabel('epochs')
ylabel('classification error')
hold off;

%weight_visualization(weights_cell{1, 1});

end

function [target] = initial_target(target, lables, minibatch_size)
for i = 1 : 1 : minibatch_size
    label = lables(i, 1);
    target(i, label + 1) = 1;
end
end

function [weights_cell, biases_cell, activations_cell] = feedforward(weights_cell, biases_cell, activations_cell, layer_input, layers_num)
for i = 1 : 1 : (layers_num - 1)
    % get the weight matrix of the hidden layer
    weights = weights_cell{1, i};
    % get the bias matrix of the hidden layer
    biases = biases_cell{1, i};
    % calculate the preactivation of the current layer
    % use the formula: z = W * X + b
    pre_activation = pre_activate(weights, biases, layer_input);
    % calculate the activation of current layer
    % use the sigmoid function: 1 / (1 + exp(z))
    % and update the layer_input with the activation
    layer_input = sigmoid(pre_activation);
    % layer_input = relu(pre_activation);
    % layer_input = tanh(pre_activation);
    % save the activation of the current layer
    activations_cell{1, i} = layer_input;
end
% output from the output layer
% get the weight matrix of the output layer
weights = weights_cell{1, layers_num};
% get the bias matrix of the output layer
biases = biases_cell{1, layers_num};
% calculate the pre_activation of the output layer:
pre_activation = pre_activate(weights, biases, layer_input);
% calculate the output of the network with the softmax function
% exp(z_j) / sum(exp(z))
network_output = softmax(pre_activation);
% save the output of the network
activations_cell{1, layers_num} = network_output;
end

function [weights_del_cell, biases_del_cell] = propagation(activations_cell, weights_del_cell, biases_del_cell, weights_cell, input_layer, layers_num, target)
% calculate delta of the output layer
% the activation function of the previous hidden layer, which
% is used to calculate weight_delta of the output layer
activation = activations_cell{1, layers_num - 1};
% calculate the delta of the output layer, use the formula:
% delta = output - target(elementwise)
network_output = activations_cell{1, layers_num};
delta_output_layer = cross_entropy_prime(network_output, target);
% calculate gradient of the weights, by using the formula:
% weight_delta = delta * activation_of_previous_layer
weight_delta = get_weight_delta(delta_output_layer, activation);
% get the original weights_delta and bias_delta
weight_delta_ori = weights_del_cell{1, layers_num};
bias_delta_ori = biases_del_cell{1, layers_num};
% accumulate weight_delta and bias_delta and average them after
% every minibatch
weights_del_cell{1, layers_num} = (weight_delta_ori + weight_delta);
biases_del_cell{1, layers_num} = bias_delta_ori + delta_output_layer;
% update delta_pre, which is used to calculate the delta of

% hidden layers in bp algorithm
delta_pre = delta_output_layer;
% calculate delta of the hidden layers
for j = layers_num - 1 : -1 : 1
    % get the weights to get the weighted delta of the hidden
    % neurons. Here, it firstly is set to be the weights out the output
    % layer.
    weight_last_layer = weights_cell{1, j + 1};
    % calculate the sum of
    % the deltas from last layer
    delta_pre_sum = get_prev_layer_delta_sum(weight_last_layer, delta_pre);
    % Get the activation of the current layer
    activation_cur_layer = activations_cell{1, j};
    % Get the activation of the previouse layer, if previous
    % layer is the input layer, the activation will be the input
    % data
    if j ~= 1
        activation_pre_layer = activations_cell{1, j - 1};
    else
        activation_pre_layer = input_layer;
    end
    % calculate the delta of the current layer
    
    % delta = weights(l+1)' * delta(l+1) * (da/dz) 
    delta = delta_pre_sum .* simoid_prime(activation_cur_layer);
    % delta = delta_pre_sum .* relu_prime(activation_cur_layer);
    % delta = delta_pre_sum .* tanh_prime(activation_cur_layer);
    % calculate the weight_delta of the current layer
    % weight_delta = a(l-1) * delta
    weight_delta = get_weight_delta(delta, activation_pre_layer);
    % calculate the bias_delta of the current layer
    weight_delta_ori = weights_del_cell{1, j};
    bias_delta_ori = biases_del_cell{1, j};
    % accumulate the weight_delta and bias_delta
    weights_del_cell{1, j} = (weight_delta_ori + weight_delta);
    biases_del_cell{1, j} = bias_delta_ori + delta;
    delta_pre = delta;
end
end

function [] = weight_visualization(weight_matrix)
[row, col] = size(weight_matrix);
figure(5)
set(gca, 'Units', 'normalized', 'Position', [0 0 0 0]);
for i = 1 : 1 : row
    matrix_temp = weight_matrix(i, :);
    weight_temp = reshape(matrix_temp, 28 ,28)';
    subplot(10, 10, i)
    imshow(weight_temp)
end
end

function [weight_delta] = get_weight_delta(delta, activation)
weight_delta = delta' * activation;
end

% 1* 10 * 10 * 100
% delta = (weight(l+1))' dot delt(l+1)
function [delta_pre_sum] = get_prev_layer_delta_sum(prev_layer_weight, delta_pre)
delta_pre_sum =  delta_pre * prev_layer_weight;
end

function [activation] = sigmoid(z)
activation = 1.0 ./ (1.0 + exp(-z));
end

function [sigmoid_prime] = simoid_prime(out)
sigmoid_prime = out .* (1 - out);
end

function [activation] = relu(z)
activation = max(0, z);
end

function [activation] = tanh(z)
activation = (exp(z) - exp(-z)) ./ (exp(z) + exp(-z));
end

function [tanh_prime] = tanh_prime(out)
tanh_prime = 1 - out.^2;
end

function [relu_prime] = relu_prime(out)
[row, col] = size(out);
relu_prime = zeros(row, col);
for i = 1 : 1 :row
    for j = 1 : 1 : col
        if out(i, j) > 0
            relu_prime(i,j) = 1;
        end
    end
end
end

% x is the input, is a matrix with the shape(1, data_dimensions),
% example:[1, 784]
% weights is a matrix with the shape(neuron_nums, input_data_dimensions),
% example:[100, 784]
% biases is a matrix with the shape(1, neuron_nums)
% example:[1, 100]
% pre_activation is a matrix with the shape(, neuron_nums)
% example:[1, 100]
function [pre_activation] = pre_activate(weights, biases, x)
pre_activation = x * weights' + biases;
end

function [output] = softmax(z)
softmax_sum = sum(exp(z),2);
[row, col] = size(z);
output = zeros(row, col);
for i = 1 : 1 : row
    output(i, :) = exp(z(i, :)) ./ softmax_sum(i, 1);
end
%output = exp(z) ./ softmax_sum;
end

function [loss] = cross_entropy(network_output, label)
log_val = log(network_output);
loss_tmp = (label .* log_val);
loss = -sum( loss_tmp, 2);

if isnan(loss)
    label
    network_output
    log(network_output)
end
end

function [delta_output_layer] = cross_entropy_prime(network_output, label)
delta_output_layer = network_output - label;
end

function [weights_cell, biases_cell, activations_cell, weights_del_cell, biases_del_cell, weigths_del_prev_cell] = para_initial(hidden_layers_size, minibatch_size)
pre_hidden_size = 784;
layers_num = length(hidden_layers_size) + 1;
weights_cell{1, layers_num} = [];
weigths_del_prev_cell{1, layers_num} = [];
biases_cell{1, layers_num} = [];
activations_cell{1, layers_num} = [];
activations_validate_cell{1, layers_num} = [];
weights_del_cell{1, layers_num} = [];
biases_del_cell{1, layers_num} = [];
for i = 1 : 1 : layers_num
    if i == layers_num
        hidden_size = 10;
    else
        hidden_size = hidden_layers_size(i);
    end
    %pre_hidden_size
    %hidden_size
    rand_size = sqrt(6.0 / (pre_hidden_size + hidden_size));
    %[output_size, input_size] = size(weights);
    % Generate the random number within (-rand_size, rand_size)
    % In general, you can generate N random numbers in the interval (a,b) with the formula r = a + (b-a).*rand(N,1).
    weights = (-rand_size) + (rand_size + rand_size) * rand(hidden_size, pre_hidden_size);
    %weights = ones(hidden_size, pre_hidden_size);
    weights_del = zeros(hidden_size, pre_hidden_size);
    %size(weights)
    %size(weights_del)
    biases = zeros(minibatch_size,hidden_size);
    biases_del = zeros(minibatch_size, hidden_size);
    activations = zeros(minibatch_size, hidden_size);
    weights_cell{1, i} = weights;
    biases_cell{1, i} = biases;
    activations_cell{1, i} = activations;
    activations_validate_cell{1, i} = activations;
    weights_del_cell{1, i} = weights_del;
    weigths_del_prev_cell{1, i} = weights_del;
    biases_del_cell{1, i} = biases_del;
    pre_hidden_size = hidden_size;
end
end

function [data_mat] = load_data(datapath)
data = textread(datapath,'','delimiter',',');

data_mat = vec2mat(data, 785);
end

function [x, label] = process_data(data)
x = data(:, 1:784);
label = data(:, 785);
end

function [success] = classification_success(network_output, target)
[row, col] = size(network_output);
success = 0;
for i = 1 : 1 : row
    probability = network_output(i,1);
    class = 1;
    for j = 2 : 1 : col
        if(network_output(i, j) > probability)
            probability = network_output(i, j);
            class = j;
        end
    end
    if target(i, class) == 1
        success = success + 1;
    end
end
end

function [biases_cell_validate] = expand_biases_validate_cell(biases_cell, layers_num, size_to_expand)    
    biases_cell_validate{1, layers_num} = [];
    for i = 1 : 1 : layers_num
        biases = biases_cell{1, i};
        [row, col] = size(biases);
        biases_validate = zeros(size_to_expand, col);
        for j = 1 : 1 : size_to_expand
            biases_validate(j, :) = biases(1, :);
        end
        biases_cell_validate{1, i} = biases_validate;
    end
end

function [loss_validate, success_num_validate] = validate_network(weights_cell, biases_cell, layers_num ,x_validate, labels_validate)

success_num_validate = 0;
loss_validate = 0;
target = zeros(1000, 10);
lable = labels_validate(1 : 1000, 1);
target = initial_target(target, lable, 1000);
layer_input = x_validate(1 : 1000, :);
activations_cell{1, layers_num} = [];
biases_cell_validate = expand_biases_validate_cell(biases_cell, layers_num, 1000);
[~, ~, activations_cell] = feedforward(weights_cell, biases_cell_validate, activations_cell, layer_input, layers_num);

network_output = activations_cell{1, layers_num};
loss_validate =  cross_entropy(network_output, target);
success_num_validate = classification_success(network_output, target);
end

function [loss_testing, success_num_testing] = test_network(weights_cell, biases_cell, layers_num, x_test, labels_test)
target = zeros(3000, 10);
lable = labels_test(1 : 3000, 1);
target = initial_target(target, lable, 3000);
layer_input = x_test(1 : 3000, :);
activations_cell{1, layers_num} = [];
biases_cell_test = expand_biases_validate_cell(biases_cell, layers_num, 3000);
[~, ~, activations_cell] = feedforward(weights_cell, biases_cell_test, activations_cell, layer_input, layers_num);
network_output = activations_cell{1, layers_num};
loss_testing = cross_entropy(network_output, target);
success_num_testing = classification_success(network_output, target);
end
