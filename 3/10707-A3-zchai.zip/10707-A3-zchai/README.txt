1. To get vocabulary please use the dataProcess.m file. And excute the command:
	dataProcess(inputPath, outputPath)
	-inputPath is the text file, like 'train.txt'
	-outputPath is the file that you want to save the vocabulary, like 'vocabulary.txt'
2. To construct 4-grams please use the construct_4_gram.m file. And excute the command:
	construct_4_gram(inputPath, dictPath, outputGramPath)
	-inputPaht is the text file, like 'train.txt'
	-dictPath is the file of vocabulary, like 'vocabulary.txt'
	-outputGramPaht is the file that you want to save all the 4-grams, like 'four_gram_train.txt'
3. To plot the distribution of 4-grams please use the drawing_4_gram.m. And excute the command:
	drawing_four_gram(trainGramPath)
	-trainGramPath is a file that contains a sorted by frequency 4-grams. 
4. To train the language model please use the train_nnlm.m file. And excute the command:
	train_nnlm(num_hid, learning_rate, batchsize, epochs, non_linear, dictPath, trainGramPath, validGramPath)
	-num_hid: the number of hidden neurons
	-learning_rate: learning rate, like 0.1
	-batchsize: such as 128, 512
	-epochs: number of epchs
	-non_linear: if is 0, use linear method, if is 1, use non-linear method. 
	-dictPath: the path contains vocabulary
	-trainGramPath: path of training 4-grams
	-validGramPath: path of valid 4-grams
	Note: there's no parameters ot change the dimension of word embbedding vector. It is hard coded as 16. 
5. To predict_sentence please use predict_sentence.m. And excute function [] = predict_sentence(dictPath, word1, word2, word3, non_linear)
	-dictPath: the path contains vocabulary
	-word1: the first word
	-word2: the second word
	-word3: the third word
	-non_linear: if is 0, use linear method, if is 1, use non-linear method. 
6. To calculate distance between words, please use word_sijmilarity.m. And excute command
	word_similarity(dictPath, word1, word2)
	-dictPath: the path contains vocabulary
	-word1: the first word
	-word2: the second word
7. To visualize the word embedding, please use the visualize_embedding.m file. And excute the command visualize_embedding(weightsPath, dictPath);
	-weightsPath: the weights of embedding word
	-dictPath: the path contains vocabulary
	Note: To use this function, you need to train a model that with word embedding dimension [1, 2]. And you need to change the "numhid1 = 16" to "numhid1 = 2" in train_nnlm.m file