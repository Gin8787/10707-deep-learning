function [] = construct_4_gram(inputPath, dictPath, outputGramPath)
dictionary = containers.Map;
fourGram = containers.Map;

% Read dictionary
finDict = fopen(dictPath);
while ~feof(finDict)
    tline = fgetl(finDict);
    if ~isempty(tline)
        lineSplit = regexp(tline, '\s+', 'split');
        word = lineSplit{1, 2};
        id = str2num(lineSplit{1, 1});
        dictionary(word) = id; 
    end
end
fclose(finDict);

% Get frequency of 4-Gram
fidin = fopen(inputPath);
index = 0;

while ~feof(fidin)
    tline = fgetl(fidin);
    if ~isempty(tline)
        tline = lower(tline);
        lineSplit = regexp(tline, '\s+', 'split');
        [row, wordNum] = size(lineSplit);
        
        if index == 60
            index
        end
        
        % The last word is normal word
        for i = 3 : 1 : wordNum
            word = lineSplit{1, i};
            if ~dictionary.isKey(word)
                word = 'UNK';
            end        
            gram = [word, ' '];
            
            for j = i - 1 : -1 : (i - 3)
                if j > 0
                    wordPrev = lineSplit{1, j};
                else 
                    wordPrev = 'START';
                end
                
                
                
                
                if strcmp(gram, 'said 0 it ')
                    wordPrev
                end
                
                if ~dictionary.isKey(wordPrev)
                    wordPrev = 'UNK';
                end
                
                gram = [gram, wordPrev, ' '];
            end
            
            if fourGram.isKey(gram)
                gramFreq = fourGram(gram);
                gramFreq = gramFreq + 1;
                fourGram(gram) = gramFreq;
            else
                fourGram(gram) = 1;
            end
        end
        
        % The last word is 'END'
        gram = 'END ';
        for j = wordNum : -1 : (wordNum - 2)
            if j > 0
                    wordPrev = lineSplit{1, j};
            else 
                    wordPrev = 'START';
            end
                
            if ~dictionary.isKey(wordPrev)
                wordPrev = 'UNK';
            end
            gram = [gram, wordPrev, ' '];
         
        end
        if fourGram.isKey(gram)
            gramFreq = fourGram(gram);
            gramFreq = gramFreq + 1;
            fourGram(gram) = gramFreq;
        else
            fourGram(gram) = 1;
        end
        
    end
    index = index + 1;
end
fclose(fidin);

% write 4gram-freqeuency pair to file
'write four gram to file'
ftemp = fopen('gramTemp.txt', 'w');
gramKey = keys(fourGram);
gramSize = size(fourGram);
for i = 1: 1 :gramSize
    gram = gramKey{1, i};
    freq = fourGram(gram);
    fprintf(ftemp, '%s %d\n', gram, freq);
end
fclose(ftemp);

% Construct struct of 4-gram and sort by gram frequency
'construct 4-gram and sort by gram frequency'
fidin = fopen('gramTemp.txt');
index = 1;
gram_struct = repmat(struct('gram', '', 'freq', 0), [1, gramSize]);
while ~feof(fidin)
    tline = fgetl(fidin);
    if ~isempty(tline)
        lineSplit = regexp(tline, '\s+', 'split');
        gram = [lineSplit{1, 4}, ' ', lineSplit{1, 3}, ' ', lineSplit{1, 2}, ' ', lineSplit{1, 1}, ' '];
        gram_struct(index).gram = gram;
        temp = lineSplit{1, 5};
        gram_struct(index).freq = str2num(temp);
    end
    index = index + 1;
end
gramCell = struct2cell(gram_struct);
sz_gram = size(gramCell)
gramCell = reshape(gramCell, sz_gram(1), []);
gramCell = gramCell';
gramCell = sortrows(gramCell, -2);


% write the sorted gram to file
'write sorted four gram to file'
fout = fopen(outputGramPath, 'w');
size_gram = size(gramCell)

for i = 1 : 1 : size_gram
    gram = gramCell{i, 1};
    freq = gramCell{i, 2};
    fprintf(fout, '%d %s %d\n', i, gram, freq);
end
end