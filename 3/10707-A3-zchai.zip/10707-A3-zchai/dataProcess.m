function [] = dataProcess(inputPath, outputPath)
dictionary = containers.Map;
fourGram = containers.Map;
fidin = fopen(inputPath);

% Count frequency of different word
while ~feof(fidin)
    tline = fgetl(fidin);
    if ~isempty(tline)
        tline = lower(tline);
        lineSplit = regexp(tline, '\s+', 'split');
        [row, wordNum] = size(lineSplit);
        for i = 1 : 1 : wordNum
            word = lineSplit{1, i};
            % Get frequency of word
            if dictionary.isKey(word)
                freq = dictionary(word);
                freq = freq + 1;
                dictionary(word) = freq;
            else
                dictionary(word) = 1;
            end
            
            % Get frequency of 4Gram             
             if i > 3
                 %gram = word;
                 gram = [word, ' '];
                 for j = i - 1 : -1 : (i-3)
                     wordPrev = lineSplit{1, j};
                     %gram = char(gram, wordPrev);
                     gram = [gram, wordPrev, ' '];
                 end
              
                 if fourGram.isKey(gram)
                     gramFreq = fourGram(gram);
                     gramFreq = gramFreq + 1;
                     fourGram(gram) = gramFreq;
                 else
                     fourGram(gram) = 1;
                 end         
             end
            
        end
    end
end
fclose(fidin);

% wirte word-frequency pair to file
ftemp = fopen('wordTemp.txt', 'w');
wordKey = keys(dictionary);
dictSize = size(dictionary);
for i = 1 : 1 : dictSize
    word = wordKey{1, i};
    freq = dictionary(word);
    fprintf(ftemp, '%s %d\n', word, freq);
end
fclose(ftemp);



% Construct struct of vocabulary and sort by word frequency
fidin = fopen('wordTemp.txt');
index = 1;
dict_struct = repmat(struct('word', '', 'freq', 0), [1, dictSize]);
while ~feof(fidin)
    tline = fgetl(fidin);
    if ~isempty(tline)
        lineSplit = regexp(tline, '\s+', 'split');
        dict_struct(index).word = lineSplit{1, 1};
        temp = lineSplit{1, 2};
        dict_struct(index).freq = str2num(temp);
    end
    index = index + 1;
end
dictCell = struct2cell(dict_struct);
sz = size(dictCell)
dictCell = reshape(dictCell, sz(1), []);
dictCell = dictCell';
dictCell = sortrows(dictCell, -2);


% write the sorted vacabulary to file
fout = fopen(outputPath, 'w');
size(dictCell)
for i = 1 : 1 : 7997
%    word = dict_struct(i).word;
%    freq = dict_struct(i).freq;
    
    word = dictCell{i, 1};
    freq = dictCell{i, 2};
    fprintf(fout, '%d %s %d\n', i, word, freq);
end

fprintf(fout, '7998 START 0\n');
fprintf(fout, '7999 END 0\n');
fprintf(fout, '8000 UNK 0\n');

fclose(fout);



end