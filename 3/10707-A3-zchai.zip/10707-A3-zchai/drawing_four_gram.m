function [] = drawing_four_gram(trainGramPath)
% readint training data
finTrain = fopen(trainGramPath);
[train_data] = textscan(finTrain, '%s %s %s %s %s %d');
% sz_train = size(train_data{1, 1}, 1);
% train_input = zeros(3, sz_train);
% train_target = zeros(1, sz_train);

four_gram = cell(100, 1);
frequency = zeros(100, 1);

for i = 1 : 1 : 100
    gram_1 = train_data{1, 4}{i, 1};
    gram_2 = train_data{1, 3}{i, 1};
    gram_3 = train_data{1, 2}{i, 1};
    target = train_data{1, 5}{i, 1};
    freq = train_data{1, 6}(i);
    gram = [gram_3, ' ', gram_2, ' ', gram_1, ' ', target];
       
    four_gram{i, 1} = gram;
    frequency(i) = freq;
end
fclose(finTrain);

plot(frequency)
title('Distribution of four gram');
xlabel('Frequency')
ylabel('Four gram')
set(gca, 'XTickLabel', four_gram);
set(gca,'XTick',0:1:100);
xtickangle(90)
end