function [perplexity] = evaluate(inputs, targets, model, non_linear)
input_size = size(inputs, 2);
% numbatches = floor(input_size / batchsize);
vocab_size = size(model.vocab, 1);
one_hoc_vocab = eye(vocab_size);

input_batch = inputs;
target_batch = targets;
[embedding_layer_state, hidden_layer_state, output_layer_state] = forward_prop(input_batch, model, non_linear);
expanded_target_batch = one_hoc_vocab(:, target_batch);
l = -sum(sum(expanded_target_batch .* log2(output_layer_state))) / input_size;
perplexity = power(2, l);

end