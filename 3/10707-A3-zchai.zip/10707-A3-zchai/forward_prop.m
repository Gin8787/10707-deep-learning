function [embedding_layer_state, hidden_layer_state, output_layer_state] = forward_prop(input_batch, model, non_linear)
% Forward propagation throught the neural language model
[num_words, batchsize] = size(input_batch);
[vocab_size, numhid1] = size(model.word_embedding_weights);
% numhid2 = size(model.embed_to_hid_weights, 2);

%% Word Embedding Layer
% Look up the inputs word indices in the word_embedding_weights matrix.
embedding_layer_state = reshape(...
    model.word_embedding_weights(reshape(input_batch, 1, []), :)', ...
    numhid1 * num_words, []);

%% COMPUTE STATE OF HIDDEN LAYER
% Compute inputs to hidden units
temp = model.embed_to_hid_weights';
temp2 = embedding_layer_state;
inputs_to_hid = model.embed_to_hid_weights' * embedding_layer_state + repmat(model.hid_bias, 1, batchsize);

if non_linear == 1
    hidden_layer_state = inputs_to_hid;
else
    %exp(inputs_to_hid)
    %exp(-inputs_to_hid)
    hidden_layer_state = (exp(inputs_to_hid) - exp(-inputs_to_hid)) ./  (exp(inputs_to_hid) + exp(-inputs_to_hid));
    %hidden_layer_state = 1 ./ (1 + exp(-inputs_to_hid));
end

%% COMPUT STATE OF OUTPUT LAYER
inputs_to_softmax = model.hid_to_output_weights' * hidden_layer_state + repmat(model.output_bias, 1, batchsize);

% Subtract maximum which makes all inputs <= 0. This prevents overflows
% when computing their exponents
 inputs_to_softmax = inputs_to_softmax - repmat(max(inputs_to_softmax), vocab_size, 1);

output_layer_state = exp(inputs_to_softmax);
output_layer_state = output_layer_state ./ repmat(sum(output_layer_state, 1), vocab_size, 1);
end