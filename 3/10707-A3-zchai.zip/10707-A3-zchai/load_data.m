function [train_input, train_target, valid_input, valid_target, vocabulary] = load_data(dictPath, trainGramPath, validGramPath)
vocabulary = containers.Map;

finDict = fopen(dictPath);
while ~feof(finDict)
    tline = fgetl(finDict);
    if ~isempty(tline)
        lineSplit = regexp(tline, '\s+', 'split');
        word = lineSplit{1, 2};
        id = str2num(lineSplit{1, 1});
        vocabulary(word) = id;
    end
end
fclose(finDict);

% readint training data
finTrain = fopen(trainGramPath);
[train_data] = textscan(finTrain, '%s %s %s %s %s %s');
sz_train = size(train_data{1, 1}, 1);
train_input = zeros(3, sz_train);
train_target = zeros(1, sz_train);

for i = 1 : 1 : sz_train
    if i == 80000
        i
    end
    gram_1 = train_data{1, 4}{i, 1};
    gram_2 = train_data{1, 3}{i, 1};
    gram_3 = train_data{1, 2}{i, 1};
    target = train_data{1, 5}{i, 1};
    if vocabulary.isKey(gram_1)
        train_input(3, i) = vocabulary(gram_1);
    else
        train_input(3, i) = vocabulary('UNK');
    end
         
    if vocabulary.isKey(gram_2)
        train_input(2, i) = vocabulary(gram_2);
    else
        train_input(2, i) = vocabulary('UNK');
    end
         
    if vocabulary.isKey(gram_3)
        train_input(1, i) = vocabulary(gram_3);
    else
        train_input(1, i) = vocabulary('UNK');
    end
         
    if vocabulary.isKey(target)
        train_target(i) = vocabulary(target);
    else
        train_target(i) = vocabulary('UNK');
    end
end
fclose(finTrain);

% reading validation data
finValid = fopen(validGramPath);
[valid_data] = textscan(finValid, '%s %s %s %s %s %s');
sz_valid = size(valid_data{1, 1}, 1);
valid_input = zeros(3, sz_valid);
valid_target = zeros(1, sz_valid);

for i = 1 : 1 : sz_valid
    if i == 10000
        i
    end
    gram_1 = valid_data{1, 4}{i, 1};
    gram_2 = valid_data{1, 3}{i, 1};
    gram_3 = valid_data{1, 2}{i, 1};
    target = valid_data{1, 5}{i, 1};
    if vocabulary.isKey(gram_1)
        valid_input(3, i) = vocabulary(gram_1);
    else
        valid_input(3, i) = vocabulary('UNK');
    end
         
    if vocabulary.isKey(gram_2)
        valid_input(2, i) = vocabulary(gram_2);
    else
        valid_input(2, i) = vocabulary('UNK');
    end
         
    if vocabulary.isKey(gram_3)
        valid_input(1, i) = vocabulary(gram_3);
    else
        valid_input(1, i) = vocabulary('UNK');
    end
         
    if vocabulary.isKey(target)
        valid_target(i) = vocabulary(target);
    else
        valid_target(i) = vocabulary('UNK');
    end
end
fclose(finValid);

% finTrain = fopen(trainGramPath);
% index = 1;
% while ~feof(finTrain)
%     tline = fgetl(finTrain);
%     if ~isempty(tline)
%         input_piece = zeros(3, 1);
%         lineSplit = regexp(tline, '\s+', 'split');
%         gram_1 = lineSplit{1, 4};
%         gram_2 = lineSplit{1, 3};
%         gram_3 = lineSplit{1, 2};
%         target = lineSplit{1, 5};
%         if ~vocabulary.isKey(gram_1)
%             input_piece(1) = vocabulary.(gram_1);
%         else
%             input_piece(1) = vocabulary.('UNK');
%         end
%         
%         if ~vocabulary.isKey(gram_2)
%             input_piece(2) = vocabulary.(gram_2);
%         else
%             input_piece(2) = vocabulary.('UNK');
%         end
%         
%         if ~vocabulary.isKey(gram_3)
%             input_piece(3) = vocabulary.(gram_3);
%         else
%             input_piece(3) = vocabulary.('UNK');
%         end
%         
%         if ~vocabulary.isKey(target)
%             id_target = vocabulary.(target);
%         else
%             id_target = vocabulary.('UNK');
%         end
%         train_input(:, index) = input_piece;
%         train_target(:, index) = id_target;
%         index = index + 1;
%     end
% end
% fclose(finTrain);
end