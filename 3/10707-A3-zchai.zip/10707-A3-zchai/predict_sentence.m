function [] = predict_sentence(dictPath, word1, word2, word3, non_linear)
temp1 = textread('word_embedding_weights.txt','','delimiter',' ');
col = size(temp1, 2);
model.word_embedding_weights = temp1(:, 1 : col - 1);

temp2 = textread('embed_hid_weights.txt','','delimiter',' ');
col = size(temp2, 2);
model.embed_to_hid_weights = temp2(:, 1 : col - 1);

temp3 = textread('hid_output_weights.txt','','delimiter',' ');
col = size(temp3, 2);
model.hid_to_output_weights = temp3(:, 1 : col - 1);

temp4 = textread('hid_bias.txt','','delimiter',' ');
col = size(temp4, 2);
model.hid_bias = temp4(:, 1 : col - 1);

temp5 = textread('output_bias.txt','','delimiter',' ');
col = size(temp5, 2);
model.output_bias = temp5(:, 1 : col - 1);

model.vocab = readModelVocabulary(dictPath);

vocabulary = readVocabulary(dictPath);

if model.vocab.isKey(word1)
    id1 = model.vocab(word1);
else
    id1 = model.vocab('UNK');
end

if model.vocab.isKey(word2)
    id2 = model.vocab(word2);
else
    id2 = model.vocab('UNK');
end

if model.vocab.isKey(word3)
    id3 = model.vocab(word3);
else
    id3 = model.vocab('UNK');
end

predict_input = [id1; id2; id3;]

for i = 1 : 1 : 10
    [embedding_layer_state, hidden_layer_state, output_layer_state] = forward_prop(predict_input, model, non_linear);
    [max_value, id_max] = max(output_layer_state(:));
    predict_word = cell2mat(vocabulary(id_max, :))
    if strcmp(predict_word, 'END')
        break;
    end
    predict_input(1, :) = predict_input(2, :);
    predict_input(2, :) = predict_input(3, :);
    predict_input(3, :) = id_max;
end

end

function [vocabulary] = readVocabulary(dictPath)
finDict = fopen(dictPath);
% vocabulary = containers.Map('KeyType','int32','ValueType','char');
vocabulary = cell(8000, 1);
while ~feof(finDict)
    tline = fgetl(finDict);
    if ~isempty(tline)
        lineSplit = regexp(tline, '\s+', 'split');
        word = lineSplit{1, 2};
        id = str2num(lineSplit{1,1});
        vocabulary{id, 1} = word;
    end
end
fclose(finDict);
end

function [model_vocab] = readModelVocabulary(dictPath)
model_vocab = containers.Map;

finDict = fopen(dictPath);
while ~feof(finDict)
    tline = fgetl(finDict);
    if ~isempty(tline)
        lineSplit = regexp(tline, '\s+', 'split');
        word = lineSplit{1, 2};
        id = str2num(lineSplit{1, 1});
        model_vocab(word) = id;
    end
end
fclose(finDict);
end