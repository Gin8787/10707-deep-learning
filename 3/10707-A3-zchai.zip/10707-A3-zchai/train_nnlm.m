function [model] = train_nnlm(num_hid, learning_rate, batchsize, epochs, non_linear, dictPath, trainGramPath, validGramPath)
% change this number to change the dimension of word embedding
numhid1 = 16;
numhid2 = num_hid;

[train_input, train_target, valid_input, valid_target, vocab] = load_data(dictPath, trainGramPath, validGramPath);

[num_words, train_size] = size(train_input);
[numbatches] = floor(train_size / batchsize);
vocab_size = size(vocab, 1);
loss_train = zeros(1, epochs);
perplexity_valid = zeros(1, epochs);

% Initialize weights and biases
% vocab_size: the size of vacabulary, 8000
% num_words: number of input, 4-gram has 3 input
% numhid1: dimensionality of the embedding space, 16
% numhid2: dimensionality of huidden units

% word_embedding_weights: Weights between input layer and word
% embeddinglayer
initial_bound = weight_initial_bound(num_words * numhid1, num_words);
% model.word_embedding_weights = rand(vocab_size, numhid1);
model.word_embedding_weights = (-initial_bound) + (initial_bound + initial_bound) * rand(vocab_size, numhid1);
% word_embedding_weights_delta: Delta of weight between input layer an word
% embedding layer
word_embedding_weights_delta = zeros(vocab_size, numhid1);
% word_embedding_weights_grad: Gradient caculated from last layer
word_embedding_weights_grad= zeros(vocab_size, numhid1);

% embed_to_hid_weights: Weights between word embedding layer and  hidden
% layer
initial_bound = weight_initial_bound(numhid2, num_words * numhid1);
% model.embed_to_hid_weights = rand(num_words * numhid1, numhid2);
model.embed_to_hid_weights = (-initial_bound) + (initial_bound + initial_bound) * rand(num_words * numhid1, numhid2);
% embed_to_hid_weights_delta: Delta between word embedding layer and hidden
% layer
embed_to_hid_weights_delta = rand(num_words * numhid1, numhid2);

% hid_to_output_weights: Weights between hidden layer and output softmax unit
initial_bound = weight_initial_bound(vocab_size, numhid2);
% model.hid_to_output_weights = rand(numhid2, vocab_size);
model.hid_to_output_weights = (-initial_bound) + (initial_bound + initial_bound) * rand(numhid2, vocab_size);
% hid_to_output_weights_delta: Delta of weights between hidden layer and
% output soft max unit
hid_to_output_weights_delta = zeros(numhid2, vocab_size);

% hid_bias: Bias of the hidden layer.
model.hid_bias = zeros(numhid2, 1);
% hid_bias_delta: Delta of bas of the hidden layer
hid_bias_delta = zeros(numhid2, 1);

% output_bias: Bias of the output layer.
model.output_bias = zeros(vocab_size, 1);
% output_bias_delta: Delta of bias of the output layer
output_bias_delta = zeros(vocab_size, 1);

% one_hoc_vocab: The one_hoc representation of vocabulary
one_hoc_vocab = eye(vocab_size);

model.vocab = vocab;


for epoch = 1 : 1 : epochs
    rnd_indices = randperm(train_size);
    train_input = train_input(:, rnd_indices);
    train_target = train_target(:, rnd_indices);
    epoch
    loss = 0;
    for m = 1 : 1 : numbatches
    %for m = 1 : 1 : 1    
        input_batch = train_input(:, 1+(m-1)*batchsize : m*batchsize);
        target_batch = train_target(:, 1+(m-1)*batchsize : m*batchsize);
        
        % FORWARD PROPAGATE
        % compute the state of each layer in the network given the input
        % batch and all weights and biases.
        [embedding_layer_state, hidden_layer_state, output_layer_state] = forward_prop(input_batch, model, non_linear);
        
        % COMPUTE LOSS GRAD
        % expand the target to a one_hoc form
        expanded_target_batch = one_hoc_vocab(:, target_batch);
        % compute the derivative of cross-entropy loss function
        output_error = output_layer_state - expanded_target_batch;
        
        %output_layer_state(target_batch, :)
        %'sum output_layer'
        %sum(sum(output_layer_state))
        %expanded_target_batch(target_batch, :)
        
        % COMPUTE LOSS FUNCTION OF TRAINING dATA
        cross_entropy = -sum(sum(expanded_target_batch .* log(output_layer_state))) / batchsize;
        %size(cross_entropy)
        %fprintf(1, 'The loss of training data is: %.4f\n', cross_entropy);
        loss = loss + cross_entropy;
        
        % BACK PROPAGATE
        %% OUTPUT LAYER
        hid_to_output_weights_grad = hidden_layer_state * output_error';
        output_bias_grad = sum(output_error, 2);
        if non_linear == 1
            back_prop_error_1 = (model.hid_to_output_weights * output_error);
        else
            back_prop_error_1 = (model.hid_to_output_weights * output_error) .* (1 - hidden_layer_state .^ 2);
        end
        
        %% HIDDEN LAYER
        embed_to_hid_weights_grad = embedding_layer_state * back_prop_error_1';
        hid_bias_grad = sum(back_prop_error_1, 2);
        back_prop_error_2 = model.embed_to_hid_weights * back_prop_error_1;
        
        %% EMBEDDING LAYER
        word_embedding_weights_grad(:) = 0;
        % Only the input word should be updated
        for w = 1 : num_words
            word_embedding_weights_grad = word_embedding_weights_grad + ...
                one_hoc_vocab(:, input_batch(w, :)) * (back_prop_error_2(1 + (w - 1) * numhid1 : w * numhid1, :)');
        end
        
        %% UPDATE WEIGHTS AND BIASES
        
        % Embedding layer update
        word_embedding_weights_delta = word_embedding_weights_grad ./ batchsize;
        model.word_embedding_weights = model.word_embedding_weights - learning_rate * word_embedding_weights_delta;
        
        % hidden layer update
        embed_to_hid_weights_delta = embed_to_hid_weights_grad ./ batchsize;
        model.embed_to_hid_weights = model.embed_to_hid_weights - learning_rate * embed_to_hid_weights_delta;
        hid_bias_delta = hid_bias_grad ./ batchsize;
        model.hid_bias = model.hid_bias - learning_rate * hid_bias_delta;
        
        % output layer update
        hid_to_output_weights_delta = hid_to_output_weights_grad ./ batchsize;
        model.hid_to_output_weights = model.hid_to_output_weights - learning_rate * hid_to_output_weights_delta;
        output_bias_delta = output_bias_grad ./ batchsize;
        model.output_bias = model.output_bias - learning_rate * output_bias_delta;
        
       
    end
    
    loss = loss / numbatches;
    loss_train(1, epoch) = loss;
    fprintf(1, 'The loss of training data is: %.4f\n', loss);
    %% VALIDATE
    % perplexity = evaluate(valid_input, valid_target, model, batchsize, non_linear);
    perplexity = evaluate(valid_input, valid_target, model, non_linear);
    perplexity_valid(1, epoch) = perplexity;
    fprintf(1, 'The perplexity of training data is: %.4f\n', perplexity);
end 

save_parameters('word_embedding_weights.txt', model.word_embedding_weights);
save_parameters('embed_hid_weights.txt', model.embed_to_hid_weights);
save_parameters('hid_output_weights.txt', model.hid_to_output_weights);

save_parameters('hid_bias.txt', model.hid_bias);
save_parameters('output_bias.txt', model.output_bias);

figure(1)
plot(loss_train(:, 2 : epochs))

figure(2)
plot(perplexity_valid(:, 2 : epochs))
end

% Calculating weight initalization bound
function [initial_bound] = weight_initial_bound(hidnum_cur, hidnum_prev)
initial_bound = sqrt(6 / (hidnum_cur + hidnum_prev));
end

function [] = save_parameters(filePath, weights)
fout = fopen(filePath, 'w');
[row, col] = size(weights);
for i = 1 : 1 : row
    for j = 1 : 1 : col
        fprintf(fout, '%d ', weights(i, j));
    end
    fprintf(fout, '\n');
end
fclose(fout);
end