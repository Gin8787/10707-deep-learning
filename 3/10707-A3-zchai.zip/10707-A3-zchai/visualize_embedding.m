function [] = visualize_embedding(weightsPath, dictPath);
weights = readWeights(weightsPath);
vocabulary = readVocabulary(dictPath);
vacab_size = size(weights, 1)

rnd_indices = randperm(vacab_size);
weights_rnd = weights(rnd_indices, :);
vacab_rnd = vocabulary(rnd_indices, :);

weights_plot = weights_rnd(1: 500, :);
vacab_plot = vacab_rnd(1 : 500, :);

scatter(weights_plot(:, 1), weights_plot(:, 2), 8, 'black', 'filled');

text(weights_plot(:, 1), weights_plot(:, 2), vacab_plot);

% for i = 1 : 1 : 500
%     text(weights_plot(i, 1), weights_plot(i, 2), vacab_rnd{rnd_indices(i), 1})
% end

end

function [weights] = readWeights(weightsPath)
finWeights = fopen(weightsPath);
[weights] = cell2mat(textscan(finWeights, '%f %f'));
fclose(finWeights);
end

function [vocabulary] = readVocabulary(dictPath)
finDict = fopen(dictPath);
% vocabulary = containers.Map('KeyType','int32','ValueType','char');
vocabulary = cell(8000, 1);
while ~feof(finDict)
    tline = fgetl(finDict);
    if ~isempty(tline)
        lineSplit = regexp(tline, '\s+', 'split');
        word = lineSplit{1, 2};
        id = str2num(lineSplit{1,1});
        vocabulary{id, 1} = word;
        %vocabulary(id, :) = word;
    end
end
fclose(finDict);
% vocabulary = blank('')
% vocab_size = size(vocabulary_tmp);
% for i = 1 : 1 : vocab_size
%     temp = vocabulary_tmp{i, 1};
%     vocabulary(i, :) = temp;
% end
end