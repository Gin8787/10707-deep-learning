function [distance] = word_similarity(dictPath, word1, word2)
% vocabulary = readVocabulary(dictPath);
model.vocab = readModelVocabulary(dictPath);

temp1 = textread('word_embedding_weights.txt','','delimiter',' ');
col = size(temp1, 2);
word_embedding_weights = temp1(:, 1 : col - 1);

if model.vocab.isKey(word1)
    id1 = model.vocab(word1);
else
    id1 = model.vocab('UNK');
end

if model.vocab.isKey(word2)
    id2 = model.vocab(word2);
else
    id2 = model.vocab('UNK');
end

vec1 = word_embedding_weights(id1, :);
vec2 = word_embedding_weights(id2, :);

distance = sqrt(sum((vec1 - vec2) .^ 2));
% distance_size = 4000 * 7999;
% distance_struct = repmat(struct('distance', 0.0, 'word1', '', 'word2', ''), [1, distance_size]);
% index = 1;
% for i = 1 : 1 : 7999
%     for j = i + 1 : 1 : 8000
%         vec1 = word_embedding_weights(i, :);
%         vec2 = word_embedding_weights(j, :);
%         distance = sqrt(sum((vec1 - vec2) .^ 2));
%         word1 = vocabulary(i, :);
%         word2 = vocabulary(j, :);
%         distance_struct(index).distance = distance;
%         distance_struct(index).word1 = word1;
%         distance_struct(index).word2 = word2;
%         index = index + 1;
%     end
% end
% distanceCell = struct2cell(distance_struct);
% sz_distance = size(distanceCell)
% distanceCell = reshape(distanceCell, sz_distance(1), []);
% distanceCell = distanceCell';
% distanceCell = sortrows(distanceCell, 1);

% write the sorted distance to file
% 'write sorted distance to file'
% fout = fopen('sorted_distance.txt', 'w');
% size_distance = size(distanceCell);
% 
% for i = 1 : 1 : size_distance
%     distance = distanceCell{i, 1};
%     word1 = distanceCell{i, 2};
%     word2 = distanceCell{i, 3};
%     fprintf(fout, '%f, %s, %s\n', distance, word1, word2);
% end
end


function [vocabulary] = readVocabulary(dictPath)
finDict = fopen(dictPath);
% vocabulary = containers.Map('KeyType','int32','ValueType','char');
vocabulary = cell(8000, 1);
while ~feof(finDict)
    tline = fgetl(finDict);
    if ~isempty(tline)
        lineSplit = regexp(tline, '\s+', 'split');
        word = lineSplit{1, 2};
        id = str2num(lineSplit{1,1});
        vocabulary{id, 1} = word;
    end
end
fclose(finDict);
end

function [model_vocab] = readModelVocabulary(dictPath)
model_vocab = containers.Map;

finDict = fopen(dictPath);
while ~feof(finDict)
    tline = fgetl(finDict);
    if ~isempty(tline)
        lineSplit = regexp(tline, '\s+', 'split');
        word = lineSplit{1, 2};
        id = str2num(lineSplit{1, 1});
        model_vocab(word) = id;
    end
end
fclose(finDict);
end